This Xcode project is provided for your convenience,
so that you can develop on Xcode and enjoy its beautiful interface and autocomplete power.

But please do try to compile on VS2010 if you want to be a responsible C++ programmer.
It is when things start to break across platforms, and when you try to fix them, 
will you truly gain a better understanding of C++ and what makes it different from other languages.
Writing portable C++ is a skill used in games, math libraries, etc. 

Please do not modify anything in vecmath.
We may use the original vecmath to test your code.

But feel free to extend upon vecmath, as long you don't touch their .h and .cpp.

For your assignments, please don't use any external libraries found online
(e.g. gismo, cgal, qslim) without permission, as they can make some parts super trivial. 
You can however, use any libraries you want for your final project.
