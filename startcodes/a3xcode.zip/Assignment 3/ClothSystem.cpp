#include "ClothSystem.h"

//TODO: Initialize here
ClothSystem::ClothSystem()
{
}


// TODO: implement evalF
// for a given state, evaluate f(X,t)
vector<Vector3f> ClothSystem::evalF(vector<Vector3f> state)
{
	return vector<Vector3f>();
}

///TODO: render the system (ie draw the particles)
void ClothSystem::draw()
{
}

