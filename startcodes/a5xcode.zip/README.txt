If you are using XCode, please merge the follow files into your previous project.

If there are conflicts due to modification to any previous files, you will have to manually edit in the necessary updates.