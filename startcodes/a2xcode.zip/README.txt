1. Install FLTK.
	- Download the source: http://fltk.org/pub/fltk/1.3.3/fltk-1.3.3-source.tar.gz
	- unzip
	- cd into the directory
	- Use the following commands:
		    ./configure
			make
			make install
	Alternatively, you can use homebrew to install. 
2. Use the xcode project. 

