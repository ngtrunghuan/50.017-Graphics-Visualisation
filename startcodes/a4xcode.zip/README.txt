First, congrats on surviving up till now. 
Hope you have been doing fine.

This assignment doesn't use OpenGL. 

If you are using XCode, changing arguments via 
Product -> Scheme -> Edit Scheme -> Run -> Arguments 
can be quite convenient for this assignment.

The scene data and executable built can be found in the build/Products directory.



Hint for those wanting an A:

If you haven't been doing extra credits, now is a really good time to do so. 
They will not only help you cover up your midterm mistakes, 
but also help you build a solid intuition for the finals 
(even for questions that are not testing anything in extra credit).

Dr. Kit says you can jump only a grade... 
but I am sure you guys know how WIDE the B range is in ISTD, and how tiny the A range is.

The extra credits in this assignment are not as hardcore as the other assignments.
(if you have been looking at 6.837, you will know what I mean)
They should be quite doable.
