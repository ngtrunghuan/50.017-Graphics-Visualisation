Nguyen Trung HUan - 1001704

The assignment is done on macOS. 
I had a lot of difficulties figuring out the faces. However, with some help from peers, I was able to work on it. 
A copy of the executable (originally in DerivedData) is copied to the surface of the project.

Usage:
./a3 [timeStepperType] [stepSize]
[timeStepperType]: default = RK4; 'e' for ForwardEuler; 't' for Trapzoidal
[stepSize]: default = 0.04f;

While the programme is running, press 't' to switch between:
- Simple system (rotating balls)
- Pendulum system
- Cloth system




