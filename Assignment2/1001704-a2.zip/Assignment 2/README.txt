Nguyen Trung Huan - 1001704

There is still a bug in the current implementation, namingly once the m_drawSkeleton = True, animating the figure will moves the y-coordinate to be negative. I can't seem to find the bug, but it might be in the interaction in the Mesh.ccp. 

No extra credit was done.