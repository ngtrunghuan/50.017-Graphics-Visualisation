1. open terminal
2. cd to this folder
3. run the application by:
>> a0sln.exe garg.obj
>> a0sln.exe sphere.obj
>> a0sln.exe torus.obj